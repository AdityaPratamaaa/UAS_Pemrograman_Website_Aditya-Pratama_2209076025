<?php
require 'core/App.php';
require 'core/Controller.php';
require 'core/Database.php';
require 'core/Flasher.php';

require 'middleware/Authenticate.php';
require 'config/Config.php';

require 'vendor/autoload.php';
