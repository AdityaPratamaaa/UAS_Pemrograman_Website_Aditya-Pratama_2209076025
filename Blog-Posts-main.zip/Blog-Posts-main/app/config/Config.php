<?php
const BASEURL = "http://localhost/minpro 3/public";
const CONN = new mysqli('localhost', 'root', '', 'minpro3');
