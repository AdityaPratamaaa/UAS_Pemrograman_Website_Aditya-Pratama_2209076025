NIM : 2209116040<br>
NAMA : Awang Muhammad Novandra Arissaputra<br>
KELAS : Sistem Informasi A 2022<br>

Alamat Website : https://novan.janjianaja.net/<br>

Role : Super Admin<br>
username : awangarissaputra@gmail.com<br>
password : awd<br>

Role : Admin<br>
username : admin@gmail.com<br>
password : admin<br>

Role : User<br>
username : bayu@gmail.com<br>
password : 123<br>
