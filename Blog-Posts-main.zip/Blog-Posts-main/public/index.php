<?php
if (!session_id()) session_start();
require '../app/init.php';

$app = new App;

?>
